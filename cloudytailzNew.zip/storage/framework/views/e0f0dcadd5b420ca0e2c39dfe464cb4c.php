<?php $__env->startSection('title', 'Dashboard — Cloudytailz'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset_url('assets/css/dashboard.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="welcome-banner">
        <div class="welcome-text">
            <h2>Welcome back, <?php echo e(Auth::user()->name ?? 'Admin'); ?> 👋</h2>
            <p>Here's what's happening with your pet clinic today — <?php echo e(now()->format('l, d M Y')); ?></p>
            <div class="welcome-actions">
                <a href="<?php echo e(route('admin.pet-visits.index')); ?>" class="btn-banner-primary">🏠 Pet Visits</a>
                <a href="<?php echo e(route('admin.packages.index')); ?>" class="btn-banner-ghost">📦 Packages</a>
                <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn-banner-ghost">💬 Contacts</a>
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn-banner-ghost">🏷️ Categories</a>
                <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn-banner-ghost">📰 Blogs</a>
            </div>
        </div>
        <div class="welcome-emoji d-none d-md-block">🐾</div>
    </div>



    
    <div class="row g-3 mb-4">

        
        <div class="col-md-4">
            <div class="table-card h-100">
                <div class="table-card-header">
                    <h6>📊 Inquiry Status</h6>
                </div>

                <div class="d-flex quick-stats-row">
                    <div class="quick-stat flex-fill">
                        <div class="quick-stat-val color-red"><?php echo e($stats['new_count']); ?></div>
                        <div class="quick-stat-lbl">New</div>
                    </div>
                    <div class="quick-stat flex-fill">
                        <div class="quick-stat-val color-yellow"><?php echo e($stats['pending']); ?></div>
                        <div class="quick-stat-lbl">Pending</div>
                    </div>
                    <div class="quick-stat flex-fill">
                        <div class="quick-stat-val color-green"><?php echo e($stats['done']); ?></div>
                        <div class="quick-stat-lbl">Done</div>
                    </div>
                </div>

                <?php
                    $total = max($stats['total'], 1);
                    $newPct = round(($stats['new_count'] / $total) * 100);
                    $pendPct = round(($stats['pending'] / $total) * 100);
                    $donePct = round(($stats['done'] / $total) * 100);
                ?>

                <div class="p-4">
                    <div class="progress-item mb-3">
                        <div class="progress-label">
                            <span>🔴 New</span>
                            <span class="color-red"><?php echo e($newPct); ?>%</span>
                        </div>
                        <div class="progress progress-sm">
                            <div class="progress-bar bar-red" style="width:<?php echo e($newPct); ?>%"></div>
                        </div>
                    </div>
                    <div class="progress-item mb-3">
                        <div class="progress-label">
                            <span>🟡 Pending</span>
                            <span class="color-yellow"><?php echo e($pendPct); ?>%</span>
                        </div>
                        <div class="progress progress-sm">
                            <div class="progress-bar bar-yellow" style="width:<?php echo e($pendPct); ?>%"></div>
                        </div>
                    </div>
                    <div class="progress-item">
                        <div class="progress-label">
                            <span>🟢 Resolved</span>
                            <span class="color-green"><?php echo e($donePct); ?>%</span>
                        </div>
                        <div class="progress progress-sm">
                            <div class="progress-bar bar-green" style="width:<?php echo e($donePct); ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-md-8">
            <div class="table-card h-100">
                <div class="table-card-header">
                    <h6>📋 Inquiry Breakdown</h6>
                    <span class="text-muted-sm">Total <?php echo e($stats['total']); ?> inquiries</span>
                </div>
                <div class="p-4">

                    <div class="breakdown-item">
                        <div class="breakdown-icon icon-blue">🏠</div>
                        <div class="flex-grow-1">
                            <div class="breakdown-title">Pet Visit at Home</div>
                            <div class="breakdown-sub">Home/clinic visits for dogs & cats</div>
                        </div>
                        <div class="text-end">
                            <div class="breakdown-count color-blue"><?php echo e($stats['pet_visits']); ?></div>
                            <a href="<?php echo e(route('admin.pet-visits.index')); ?>" class="badge-type badge-visit link-badge">View
                                All →</a>
                        </div>
                    </div>

                    <div class="breakdown-item">
                        <div class="breakdown-icon icon-green">📦</div>
                        <div class="flex-grow-1">
                            <div class="breakdown-title">Packages</div>
                            <div class="breakdown-sub">Care & grooming package inquiries</div>
                        </div>
                        <div class="text-end">
                            <div class="breakdown-count color-teal"><?php echo e($stats['packages']); ?></div>
                            <a href="<?php echo e(route('admin.packages.index')); ?>"
                                class="badge-type badge-package link-badge">View All →</a>
                        </div>
                    </div>

                    <div class="breakdown-item">
                        <div class="breakdown-icon icon-pink">💬</div>
                        <div class="flex-grow-1">
                            <div class="breakdown-title">Contact Form</div>
                            <div class="breakdown-sub">General queries & messages</div>
                        </div>
                        <div class="text-end">
                            <div class="breakdown-count color-pink"><?php echo e($stats['contacts']); ?></div>
                            <a href="<?php echo e(route('admin.contacts.index')); ?>"
                                class="badge-type badge-contact link-badge">View All →</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

    
    <div class="table-card">
        <div class="table-card-header">
            <h6>🕐 Recent Inquiries</h6>
            <span class="text-muted-sm">Last 10 entries</span>
        </div>

        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>Type</th>
                        <th>Details</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $avatarBg = ['#fff7ed','#dbeafe','#d1fae5','#fce7f3']; ?>

                    <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="row-id">#<?php echo e(str_pad($i + 1, 3, '0', STR_PAD_LEFT)); ?></td>

                            <td>
                                <div class="name-cell">
                                    <div class="avatar-initial" style="background:<?php echo e($avatarBg[$i % 4]); ?>;">
                                        <?php echo e(strtoupper(substr($row['type'] === 'contact' ? $row['fname'] : $row['name'], 0, 1))); ?>

                                    </div>
                                    <div>
                                        <div class="name-main">
                                            <?php echo e($row['type'] === 'contact' ? $row['fname'] . ' ' . $row['lname'] : $row['name']); ?>

                                        </div>
                                        <div class="name-sub"><?php echo e($row['phone'] ?? '—'); ?></div>
                                    </div>
                                </div>
                            </td>

                            <td class="cell-muted"><?php echo e($row['email'] ?? '—'); ?></td>

                            <td>
                                <?php if($row['type'] === 'pet_visit'): ?>
                                    <span class="badge-type badge-visit">🏠 Pet Visit</span>
                                <?php elseif($row['type'] === 'package'): ?>
                                    <span class="badge-type badge-package">📦 Package</span>
                                <?php else: ?>
                                    <span class="badge-type badge-contact">💬 Contact</span>
                                <?php endif; ?>
                            </td>

                            <td class="cell-truncate">
                                <?php echo e($row['message'] ?? ($row['package'] ?? ($row['services'] ?? '—'))); ?>

                            </td>

                            <td class="cell-date">
                                <i class="bi bi-calendar3"></i>
                                <?php echo e(\Carbon\Carbon::parse($row['created_at'])->format('d M Y')); ?>

                                <div class="date-ago">
                                    <?php echo e(\Carbon\Carbon::parse($row['created_at'])->diffForHumans()); ?>

                                </div>
                            </td>

                            <td>
                                <?php if($row['status'] === 'new'): ?>
                                    <span class="badge-status badge-new">● New</span>
                                <?php elseif($row['status'] === 'pending'): ?>
                                    <span class="badge-status badge-pending">● Pending</span>
                                <?php else: ?>
                                    <span class="badge-status badge-done">✓ Done</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?php if($row['type'] === 'pet_visit'): ?>
                                    <a href="<?php echo e(route('admin.pet-visits.show', $row['id'])); ?>" class="btn-view">View
                                        →</a>
                                <?php elseif($row['type'] === 'package'): ?>
                                    <a href="<?php echo e(route('admin.packages.show', $row['id'])); ?>" class="btn-view">View →</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('admin.contacts.show', $row['id'])); ?>" class="btn-view">View →</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8">
                                <div class="empty-state">
                                    <div class="empty-icon">🐾</div>
                                    <p>No inquiries yet. They'll show up here once submitted!</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="table-footer">
            <span class="text-muted-sm">
                Showing <?php echo e(count($recent)); ?> of <?php echo e($stats['total']); ?> total inquiries
            </span>
            <a href="<?php echo e(route('admin.pet-visits.index')); ?>" class="link-orange">
                View All Pet Visits →
            </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset_url('assets/js/dashboard-us.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
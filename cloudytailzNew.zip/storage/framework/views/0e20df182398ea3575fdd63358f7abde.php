<section>
    <div class="card shadow-sm border-0">
        <div class="card-body p-4">

            <h4 class="fw-bold mb-2">
                Update Password
            </h4>

            <p class="text-muted mb-4">
                Ensure your account is using a long, random password to stay secure.
            </p>

            <form method="POST" action="<?php echo e(route('password.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="update_password_current_password" class="form-label">
                        Current Password
                    </label>

                    <input id="update_password_current_password" name="current_password" type="password"
                        class="form-control" autocomplete="current-password">

                    <?php $__errorArgs = ['current_password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label for="update_password_password" class="form-label">
                        New Password
                    </label>

                    <input id="update_password_password" name="password" type="password" class="form-control"
                        autocomplete="new-password">

                    <?php $__errorArgs = ['password', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="update_password_password_confirmation" class="form-label">
                        Confirm Password
                    </label>

                    <input id="update_password_password_confirmation" name="password_confirmation" type="password"
                        class="form-control" autocomplete="new-password">

                    <?php $__errorArgs = ['password_confirmation', 'updatePassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="d-flex align-items-center gap-3">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>

                    <?php if(session('status') === 'password-updated'): ?>
                        <span id="savedMessage" class="text-success">
                            Saved.
                        </span>

                        <script>
                            setTimeout(function() {
                                let msg = document.getElementById('savedMessage');
                                if (msg) {
                                    msg.style.display = 'none';
                                }
                            }, 2000);
                        </script>
                    <?php endif; ?>
                </div>

            </form>

        </div>
    </div>
</section>
<?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/profile/partials/update-password-form.blade.php ENDPATH**/ ?>
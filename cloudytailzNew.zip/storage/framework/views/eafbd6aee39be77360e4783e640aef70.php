<?php $__env->startSection('title', 'Profile - Dashboard |Cloudytailz'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-4 mb-5">

        <div class="row">
            <div class="col-lg-8 mx-auto">

                <h2 class="mb-4 fw-bold">
                    Profile
                </h2>


                <!-- Update Profile Information -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            Update Profile Information
                        </h5>
                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>



                <!-- Update Password -->
                <div class="card shadow-sm mb-4 border-0">
                    <div class="card-header bg-white">
                        <h5 class="mb-0">
                            Change Password
                        </h5>
                    </div>

                    <div class="card-body">
                        <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>



                <!-- Delete Account -->
                


            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/profile/edit.blade.php ENDPATH**/ ?>
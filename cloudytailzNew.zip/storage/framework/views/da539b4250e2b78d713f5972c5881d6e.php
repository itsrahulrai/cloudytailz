<section>
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-4">

            <h4 class="fw-bold mb-2">
                Profile Information
            </h4>

            <p class="text-muted mb-4">
                Update your account's profile information and email address.
            </p>

            <form id="send-verification" method="POST" action="<?php echo e(route('verification.send')); ?>">
                <?php echo csrf_field(); ?>
            </form>

            <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <div class="mb-3">
                    <label for="name" class="form-label">
                        Name
                    </label>

                    <input id="name" name="name" type="text" class="form-control"
                        value="<?php echo e(old('name', $user->name)); ?>" required autofocus autocomplete="name">

                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="mb-4">
                    <label for="email" class="form-label">
                        Email
                    </label>

                    <input id="email" name="email" type="email" class="form-control"
                        value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$user->hasVerifiedEmail()): ?>

                        <div class="mt-3">
                            <p class="small text-muted mb-2">
                                Your email address is unverified.
                            </p>

                            <button form="send-verification" class="btn btn-outline-primary btn-sm">
                                Re-send Verification Email
                            </button>

                            <?php if(session('status') === 'verification-link-sent'): ?>
                                <div class="alert alert-success mt-3 mb-0 py-2">
                                    A new verification link has been sent to your email address.
                                </div>
                            <?php endif; ?>

                        </div>

                    <?php endif; ?>

                </div>


                <div class="d-flex align-items-center gap-3">
                    <button type="submit" class="btn btn-primary">
                        Save
                    </button>

                    <?php if(session('status') === 'profile-updated'): ?>
                        <span id="profileSaved" class="text-success">
                            Saved.
                        </span>

                        <script>
                            setTimeout(function() {
                                let msg = document.getElementById('profileSaved');
                                if (msg) {
                                    msg.style.display = 'none';
                                }
                            }, 2000);
                        </script>
                    <?php endif; ?>

                </div>

            </form>

        </div>
    </div>
</section>
<?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/profile/partials/update-profile-information-form.blade.php ENDPATH**/ ?>
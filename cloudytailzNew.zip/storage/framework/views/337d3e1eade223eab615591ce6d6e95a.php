<?php $__env->startSection('title', 'Edit Category — Cloudytailz Admin'); ?>
<?php $__env->startSection('page-title', 'Edit Blog Category'); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4">
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-sm btn-outline-secondary" style="border-radius:8px;font-weight:600;padding:6px 14px;">
            <i class="bi bi-arrow-left me-1"></i> Back to Categories
        </a>
    </div>

    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="table-card">
                <div class="table-card-header d-flex align-items-center justify-content-between">
                    <div>
                        <h6 class="mb-0" style="font-weight:700;color:#1a1f36;">
                            <i class="bi bi-pencil-square text-primary me-2"></i>Edit Category: <?php echo e($category->name); ?>

                        </h6>
                        <span style="font-size:12px;color:#8b92a9;">ID #<?php echo e($category->id); ?> &bull; Created <?php echo e($category->created_at?->format('d M Y')); ?></span>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>"
                          onsubmit="return confirm('Are you sure you want to delete this category?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger" style="border-radius:8px;font-weight:600;font-size:11px;">
                            <i class="bi bi-trash3 me-1"></i> Delete
                        </button>
                    </form>
                </div>

                <div class="p-4">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger mb-4" style="border-radius:12px;">
                            <div class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-2"></i>Please fix the following errors:</div>
                            <ul class="mb-0 ps-3">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="<?php echo e(route('admin.categories.update', $category->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="mb-3">
                            <label for="name" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                                Category Name <span class="text-danger">*</span>
                            </label>
                            <input type="text"
                                   name="name"
                                   id="name"
                                   class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   value="<?php echo e(old('name', $category->name)); ?>"
                                   required
                                   style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-3">
                            <label for="slug" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                                Category Slug <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted" style="border-radius:10px 0 0 10px;font-size:13px;border-color:#e2e8f0;">
                                    blogs?category=
                                </span>
                                <input type="text"
                                       name="slug"
                                       id="slug"
                                       class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?php echo e(old('slug', $category->slug)); ?>"
                                       required
                                       style="border-radius:0 10px 10px 0;padding:10px 14px;border-color:#e2e8f0;">
                            </div>
                            <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="form-text" style="font-size:11px;color:#8b92a9;">Used in URLs to filter blogs by this category.</div>
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                                Description (Optional)
                            </label>
                            <textarea name="description"
                                      id="description"
                                      rows="3"
                                      class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;"><?php echo e(old('description', $category->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-4 p-3 rounded" style="background:#f8fafc;border:1px solid #e2e8f0;">
                            <label class="form-label mb-1" style="font-weight:700;font-size:13px;color:#334155;">Status</label>
                            <div class="form-check form-switch">
                                <input class="form-check-input"
                                       type="checkbox"
                                       role="switch"
                                       id="status"
                                       name="status"
                                       value="1"
                                       <?php echo e(old('status', $category->status) ? 'checked' : ''); ?>

                                       style="cursor:pointer;">
                                <label class="form-check-label ms-2" for="status" style="font-size:13px;color:#475569;cursor:pointer;">
                                    Active (Category will be available for blogs)
                                </label>
                            </div>
                        </div>

                        <div class="d-flex align-items-center justify-content-end gap-2 pt-2" style="border-top:1px solid #f0f2f8;">
                            <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline-secondary" style="border-radius:10px;font-weight:600;padding:8px 20px;">
                                Cancel
                            </a>
                            <button type="submit" class="btn" style="background:#f97316;color:#fff;font-weight:700;padding:8px 24px;border-radius:10px;box-shadow:0 4px 12px rgba(249,115,22,0.25);">
                                <i class="bi bi-check-lg me-1"></i> Update Category
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>
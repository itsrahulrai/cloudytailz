<?php $__env->startSection('title', 'Add New Blog — Cloudytailz Admin'); ?>
<?php $__env->startSection('page-title', 'Create New Blog'); ?>

<?php $__env->startPush('styles'); ?>
    <!-- Jodit Editor CSS -->
    <link rel="stylesheet" href="<?php echo e(asset_url('assets/vendor/jodit/jodit.min.css')); ?>"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jodit/4.12.37/es2021/jodit.min.css"/>
    <style>
        .jodit-container {
            border-radius: 12px !important;
            border-color: #e2e8f0 !important;
        }
        .form-section-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
            border: 1px solid #edf2f7;
            margin-bottom: 24px;
        }
        .form-section-title {
            font-size: 15px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 12px;
            border-bottom: 1px solid #f1f5f9;
        }
        .image-preview-box {
            width: 100%;
            height: 200px;
            border: 2px dashed #cbd5e1;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: #f8fafc;
            position: relative;
        }
        .image-preview-box img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="mb-4 d-flex align-items-center justify-content-between">
        <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-sm btn-outline-secondary" style="border-radius:8px;font-weight:600;padding:6px 14px;">
            <i class="bi bi-arrow-left me-1"></i> Back to All Blogs
        </a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-4" style="border-radius:12px;">
            <div class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-2"></i>Please fix the following errors:</div>
            <ul class="mb-0 ps-3">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.blogs.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row">
            
            <div class="col-lg-8">
                <div class="form-section-card">
                    <div class="form-section-title">
                        <i class="bi bi-pencil-fill text-warning"></i> General Information
                    </div>

                    <div class="mb-3">
                        <label for="title" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Blog Title <span class="text-danger">*</span>
                        </label>
                        <input type="text"
                               name="title"
                               id="title"
                               class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="e.g. 7 Essential Tips to Keep Your Pet Happy and Healthy"
                               value="<?php echo e(old('title')); ?>"
                               required
                               style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;font-weight:600;">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="slug" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Blog Slug (URL Identifier)
                        </label>
                        <div class="input-group">
                            <span class="input-group-text bg-light text-muted" style="border-radius:10px 0 0 10px;font-size:12px;border-color:#e2e8f0;">
                                blogs/
                            </span>
                            <input type="text"
                                   name="slug"
                                   id="slug"
                                   class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   placeholder="auto-generated-from-title"
                                   value="<?php echo e(old('slug')); ?>"
                                   style="border-radius:0 10px 10px 0;padding:10px 14px;border-color:#e2e8f0;font-size:13px;">
                        </div>
                        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text" style="font-size:11px;color:#8b92a9;">Leave blank to automatically generate from the title.</div>
                    </div>

                    <div class="mb-3">
                        <label for="short_description" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Short Summary / Excerpt
                        </label>
                        <textarea name="short_description"
                                  id="short_description"
                                  rows="3"
                                  class="form-control <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  placeholder="Brief 1-2 sentence preview shown on blog cards..."
                                  style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;"><?php echo e(old('short_description')); ?></textarea>
                        <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="content" class="form-label d-flex align-items-center justify-content-between" style="font-weight:700;font-size:13px;color:#334155;">
                            <span>Blog Full Content <span class="text-danger">*</span></span>
                           
                        </label>
                        <textarea name="content"
                                  id="content"
                                  rows="12"
                                  class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  placeholder="Write your blog content here..."><?php echo e(old('content')); ?></textarea>
                        <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div class="form-section-card">
                    <div class="form-section-title">
                        <i class="bi bi-search text-success"></i> SEO & Search Engine Optimization
                    </div>

                    <div class="mb-3">
                        <label for="meta_title" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Meta Title (SEO Title)
                        </label>
                        <input type="text"
                               name="meta_title"
                               id="meta_title"
                               class="form-control <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="e.g. Best Diet Plans for Dogs & Cats | Cloudytailz"
                               value="<?php echo e(old('meta_title')); ?>"
                               maxlength="255"
                               style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;">
                        <div class="form-text" style="font-size:11px;color:#8b92a9;">Recommended: 50-60 characters for optimal Google search snippet.</div>
                    </div>

                    <div class="mb-3">
                        <label for="meta_description" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Meta Description
                        </label>
                        <textarea name="meta_description"
                                  id="meta_description"
                                  rows="3"
                                  class="form-control <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  placeholder="Summary of the article that appears under the title in search engine results..."
                                  style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;"><?php echo e(old('meta_description')); ?></textarea>
                        <div class="form-text" style="font-size:11px;color:#8b92a9;">Recommended: 140-160 characters for maximum search visibility.</div>
                    </div>

                    <div class="mb-3">
                        <label for="meta_keywords" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Meta Keywords (Comma separated)
                        </label>
                        <input type="text"
                               name="meta_keywords"
                               id="meta_keywords"
                               class="form-control <?php $__errorArgs = ['meta_keywords'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="e.g. pet care, dog food, cat grooming, veterinary tips"
                               value="<?php echo e(old('meta_keywords')); ?>"
                               style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;">
                    </div>

                    <div class="mb-2">
                        <label for="canonical_url" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Canonical URL (Optional)
                        </label>
                        <input type="url"
                               name="canonical_url"
                               id="canonical_url"
                               class="form-control <?php $__errorArgs = ['canonical_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               placeholder="https://cloudytailz.com/blogs/..."
                               value="<?php echo e(old('canonical_url')); ?>"
                               style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;">
                        <div class="form-text" style="font-size:11px;color:#8b92a9;">Leave blank to automatically use this blog's permalink.</div>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4">
                
                <div class="form-section-card">
                    <div class="form-section-title">
                        <i class="bi bi-sliders text-primary"></i> Category & Publishing
                    </div>

                    <div class="mb-3">
                        <label for="category_id" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Select Category <span class="text-danger">*</span>
                        </label>
                        <select name="category_id"
                                id="category_id"
                                class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                required
                                style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;font-weight:600;">
                            <option value="">-- Choose Category --</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e(old('category_id') == $category->id ? 'selected' : ''); ?>>
                                    🏷️ <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php if($categories->isEmpty()): ?>
                            <div class="mt-2 text-danger" style="font-size:12px;">
                                No categories found. <a href="<?php echo e(route('admin.categories.create')); ?>">Create a category first</a>.
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="author" class="form-label" style="font-weight:700;font-size:13px;color:#334155;">
                            Author Name
                        </label>
                        <input type="text"
                               name="author"
                               id="author"
                               class="form-control"
                               placeholder="e.g. Cloudytailz Care Team"
                               value="<?php echo e(old('author', 'Cloudytailz')); ?>"
                               style="border-radius:10px;padding:10px 14px;border-color:#e2e8f0;">
                    </div>

                    <div class="p-3 rounded mb-3" style="background:#f8fafc;border:1px solid #e2e8f0;">
                        <label class="form-label mb-1" style="font-weight:700;font-size:13px;color:#334155;">Publishing Status</label>
                        <div class="form-check form-switch mt-1">
                            <input class="form-check-input"
                                   type="checkbox"
                                   role="switch"
                                   id="status"
                                   name="status"
                                   value="1"
                                   <?php echo e(old('status', '1') == '1' ? 'checked' : ''); ?>

                                   style="cursor:pointer;">
                            <label class="form-check-label ms-2" for="status" style="font-size:13px;color:#475569;cursor:pointer;font-weight:600;">
                                Published (Visible on website)
                            </label>
                        </div>
                    </div>

                    <div class="d-grid gap-2 pt-2">
                        <button type="submit" class="btn"
                                style="background:#f97316;color:#fff;font-weight:700;padding:12px;border-radius:10px;box-shadow:0 4px 14px rgba(249,115,22,0.3);font-size:14px;">
                            <i class="bi bi-cloud-arrow-up me-1"></i> Publish Blog
                        </button>
                        <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-outline-secondary" style="border-radius:10px;font-weight:600;padding:10px;">
                            Cancel
                        </a>
                    </div>
                </div>

                
                <div class="form-section-card">
                    <div class="form-section-title">
                        <i class="bi bi-image text-danger"></i> Featured Image
                    </div>

                    <div class="mb-3">
                        <div class="image-preview-box mb-2" id="previewBox">
                            <span id="previewPlaceholder" class="text-muted text-center p-3" style="font-size:12px;">
                                <i class="bi bi-cloud-arrow-up-fill d-block fs-2 text-secondary mb-1"></i>
                                Click below to upload a featured cover image<br>(JPEG, PNG, WEBP, max 5MB)
                            </span>
                            <img id="imagePreview" src="" alt="Preview">
                        </div>

                        <input type="file"
                               name="image"
                               id="imageInput"
                               accept="image/*"
                               class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               style="border-radius:10px;font-size:12px;">
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Jodit Editor JS (Local + CDN fallback) -->
    <script src="<?php echo e(asset_url('assets/vendor/jodit/jodit.min.js')); ?>"></script>
    <script>
        if (typeof Jodit === 'undefined') {
            document.write('<script src="https://cdnjs.cloudflare.com/ajax/libs/jodit/4.12.37/es2021/jodit.min.js"><\/script>');
        }
    </script>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // ── Initialize Jodit WYSIWYG Editor ──
            if (typeof Jodit !== 'undefined') {
                const joditEditor = Jodit.make('#content', {
                    height: 480,
                    theme: 'default',
                    placeholder: 'Write your engaging blog post here...',
                    toolbarAdaptive: false,
                    uploader: {
                        insertImageAsBase64URI: true
                    },
                    buttons: [
                        'bold', 'italic', 'underline', 'strikethrough', '|',
                        'paragraph', 'font', 'fontsize', 'brush', '|',
                        'ul', 'ol', 'align', '|',
                        'image', 'table', 'link', '|',
                        'hr', 'symbol', 'eraser', '|',
                        'source', 'fullsize', 'preview'
                    ]
                });
            }

            // ── Auto-generate slug from title ──
            const titleInput = document.getElementById('title');
            const slugInput = document.getElementById('slug');
            let manualSlug = false;

            slugInput.addEventListener('input', function() {
                manualSlug = slugInput.value.trim().length > 0;
            });

            titleInput.addEventListener('input', function () {
                if (!manualSlug) {
                    slugInput.value = titleInput.value
                        .toLowerCase()
                        .trim()
                        .replace(/[^\w\s-]/g, '')
                        .replace(/[\s_-]+/g, '-')
                        .replace(/^-+|-+$/g, '');
                }
            });

            // ── Live Image Preview ──
            const imageInput = document.getElementById('imageInput');
            const imagePreview = document.getElementById('imagePreview');
            const previewPlaceholder = document.getElementById('previewPlaceholder');

            imageInput.addEventListener('change', function () {
                const file = this.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function (e) {
                        imagePreview.src = e.target.result;
                        imagePreview.style.display = 'block';
                        previewPlaceholder.style.display = 'none';
                    };
                    reader.readAsDataURL(file);
                } else {
                    imagePreview.src = '';
                    imagePreview.style.display = 'none';
                    previewPlaceholder.style.display = 'block';
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/admin/blogs/create.blade.php ENDPATH**/ ?>
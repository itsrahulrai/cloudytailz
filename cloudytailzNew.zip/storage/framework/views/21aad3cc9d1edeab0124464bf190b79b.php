<?php $__env->startSection('title', 'Pet Visit Inquiries — Cloudytailz'); ?>
<?php $__env->startSection('page-title', 'Pet Visit Inquiries'); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-card">
        <div class="table-card-header">
            <h6>🏠 Pet Visit Requests</h6>
            <span style="font-size:12px;color:#8b92a9;">Total: <?php echo e($inquiries->total()); ?></span>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success mx-4 mt-3"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Service</th>
                        <th>Message</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $inquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td style="color:#8b92a9;font-size:12px;"><?php echo e($row->id); ?></td>
                            <td style="font-weight:700;"><?php echo e($row->name); ?></td>
                            <td style="font-size:12px;"><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->phone); ?></td>
                            <td><span class="badge-type badge-visit"><?php echo e(str_replace('_', ' ', $row->services)); ?></span></td>
                            <td
                                style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;color:#6b7280;">
                                <?php echo e($row->message ?? '—'); ?>

                            </td>
                            <td>
                                <form method="POST" action="<?php echo e(route('admin.pet-visits.status', $row->id)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <select name="status" onchange="this.form.submit()" class="form-select form-select-sm"
                                        style="font-size:11px;width:100px;border-radius:8px;">
                                        <option value="new" <?php echo e($row->status === 'new' ? 'selected' : ''); ?>>New</option>
                                        <option value="pending" <?php echo e($row->status === 'pending' ? 'selected' : ''); ?>>Pending
                                        </option>
                                        <option value="done" <?php echo e($row->status === 'done' ? 'selected' : ''); ?>>Done</option>
                                    </select>
                                </form>
                            </td>
                            <td class="d-flex gap-1">
                                <a href="<?php echo e(route('admin.pet-visits.show', $row->id)); ?>" class="btn btn-sm"
                                    style="background:#f4f6fb;color:#374151;font-size:11px;font-weight:700;border-radius:8px;padding:3px 10px;">View</a>
                                <form method="POST" action="<?php echo e(route('admin.pet-visits.destroy', $row->id)); ?>"
                                    onsubmit="return confirm('Delete?')">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm"
                                        style="background:#fee2e2;color:#dc2626;font-size:11px;font-weight:700;border-radius:8px;padding:3px 10px;">Del</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center py-4" style="color:#8b92a9;">No records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="px-4 py-3" style="border-top:1px solid #f0f2f8;">
            <?php echo e($inquiries->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/admin/inquiries/pet-visits.blade.php ENDPATH**/ ?>
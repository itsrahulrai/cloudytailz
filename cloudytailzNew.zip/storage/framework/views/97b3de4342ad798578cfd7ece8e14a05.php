<?php $__env->startSection('title', ($service->meta_title ?: $service->title) . ' | Cloudytailz Pet Care'); ?>
<?php $__env->startSection('meta_description', $service->meta_description ?: ($service->short_description ?: \Illuminate\Support\Str::limit(strip_tags($service->content), 155))); ?>
<?php $__env->startSection('meta_keywords', $service->meta_keywords ?: 'Cloudytailz, pet services, dog care, cat care, pet grooming, veterinary care'); ?>
<?php $__env->startSection('meta_robots', 'index, follow'); ?>
<?php $__env->startSection('canonical', $service->canonical_url ?: url()->current()); ?>


<?php $__env->startSection('seo_tags'); ?>
    <!-- Open Graph (Facebook / WhatsApp / LinkedIn) -->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Cloudytailz">
    <meta property="og:title" content="<?php echo e($service->meta_title ?: $service->title); ?>">
    <meta property="og:description" content="<?php echo e($service->meta_description ?: ($service->short_description ?: \Illuminate\Support\Str::limit(strip_tags($service->content), 155))); ?>">
    <meta property="og:url" content="<?php echo e($service->canonical_url); ?>">
    <meta property="og:image" content="<?php echo e($service->image_url); ?>">
    <meta property="og:image:alt" content="<?php echo e($service->title); ?>">

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($service->meta_title ?: $service->title); ?>">
    <meta name="twitter:description" content="<?php echo e($service->meta_description ?: ($service->short_description ?: \Illuminate\Support\Str::limit(strip_tags($service->content), 155))); ?>">
    <meta name="twitter:image" content="<?php echo e($service->image_url); ?>">

    <!-- JSON-LD: Service Schema -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "Service",
        "serviceType": "<?php echo e(addslashes($service->title)); ?>",
        "provider": {
            "@type": "LocalBusiness",
            "name": "Cloudytailz",
            "image": "<?php echo e(asset_url('assets/images/logo-png.png')); ?>",
            "url": "<?php echo e(url('/')); ?>"
        },
        "description": "<?php echo e(addslashes($service->meta_description ?: ($service->short_description ?: \Illuminate\Support\Str::limit(strip_tags($service->content), 160)))); ?>",
        "image": "<?php echo e($service->image_url); ?>"
    }
    </script>

    <!-- JSON-LD: BreadcrumbList Schema -->
    <script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Home",
                "item": "<?php echo e(url('/')); ?>"
            },
            {
                "@type": "ListItem",
                "position": 2,
                "name": "<?php echo e(addslashes($service->title)); ?>",
                "item": "<?php echo e(url()->current()); ?>"
            }
        ]
    }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .dynamic-service-body {
        font-size: 16px;
        line-height: 1.8;
        color: #4b5563;
    }
    .dynamic-service-body h2 {
        font-family: 'Nunito', sans-serif;
        font-weight: 800;
        font-size: 26px;
        color: #1a1f36;
        margin-top: 32px;
        margin-bottom: 16px;
    }
    .dynamic-service-body h3 {
        font-family: 'Nunito', sans-serif;
        font-weight: 700;
        font-size: 21px;
        color: #1a1f36;
        margin-top: 24px;
        margin-bottom: 14px;
    }
    .dynamic-service-body h4 {
        font-weight: 700;
        font-size: 18px;
        color: #1a1f36;
        margin-top: 20px;
        margin-bottom: 10px;
    }
    .dynamic-service-body p {
        margin-bottom: 18px;
    }
    .dynamic-service-body ul, .dynamic-service-body ol {
        margin-bottom: 20px;
        padding-left: 24px;
    }
    .dynamic-service-body li {
        margin-bottom: 8px;
    }
    .dynamic-service-body img {
        max-width: 100%;
        height: auto;
        border-radius: 12px;
        margin: 16px 0;
    }
    .dynamic-service-body blockquote {
        border-left: 4px solid #f97316;
        padding: 14px 20px;
        background: #fff7ed;
        border-radius: 0 12px 12px 0;
        margin: 24px 0;
        font-style: italic;
        color: #9a3412;
    }
    .dynamic-service-body table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    .dynamic-service-body th, .dynamic-service-body td {
        border: 1px solid #e5e7eb;
        padding: 10px 14px;
    }
    .dynamic-service-body th {
        background: #f8fafc;
        font-weight: 700;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Page Header Section Start -->
    <div class="page-header bg-section parallaxie">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!-- Page Header Box Start -->
                    <div class="page-header-box">
                        <h1 class="text-anime-style-3" data-cursor="-opaque"><?php echo e($service->title); ?></h1>
                        <nav class="wow fadeInUp">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">home</a></li>
                                <li class="breadcrumb-item active" aria-current="page"><?php echo e($service->title); ?></li>
                            </ol>
                        </nav>
                    </div>
                    <!-- Page Header Box End -->
                </div>
            </div>
        </div>
    </div>
    <!-- Page Header Section End -->

    <!-- Page Service Single Start -->
    <div class="page-service-single">
        <div class="container">
            <div class="row">

                <div class="col-lg-8">
                    <!-- Service Single Content Start -->
                    <div class="service-single-content">

                        <?php if(!empty($service->image)): ?>
                            <!-- Page Single image Start -->
                            <div class="page-single-image mb-4">
                                <figure class="image-anime reveal">
                                    <img src="<?php echo e($service->image_url); ?>" alt="<?php echo e($service->title); ?>" style="width:100%; border-radius:16px; object-fit:cover; max-height:480px;">
                                </figure>
                            </div>
                            <!-- Page Single image End -->
                        <?php endif; ?>

                        <!-- Service Entry Start -->
                        <div class="service-entry">
                            <?php if(!empty($service->short_description)): ?>
                                <div class="service-intro mb-4 p-4" style="background:#fff7ed; border-left:4px solid #f97316; border-radius:12px;">
                                    <p class="mb-0" style="font-size:17px; line-height:1.7; color:#9a3412; font-weight:600;">
                                        <?php echo e($service->short_description); ?>

                                    </p>
                                </div>
                            <?php endif; ?>

                            
                            <div class="dynamic-service-body">
                                <?php echo $service->content; ?>

                            </div>

                            
                            <div class="mt-5 p-4 p-md-5 d-flex flex-column flex-md-row align-items-center justify-content-between gap-3"
                                 style="background:linear-gradient(135deg, #1a1f36 0%, #2d3748 100%); border-radius:18px; color:#fff;">
                                <div>
                                    <h3 class="text-white mb-2" style="font-weight:800; font-size:22px;">Ready to Book <?php echo e($service->title); ?>?</h3>
                                    <p class="mb-0 text-white-50" style="font-size:14px;">Contact our friendly pet care specialists today to schedule your session.</p>
                                </div>
                                <div class="flex-shrink-0">
                                    <a href="<?php echo e(route('contact')); ?>" class="btn-default" style="box-shadow:0 6px 20px rgba(249,115,22,0.4);">
                                        Book Appointment
                                    </a>
                                </div>
                            </div>

                            <?php if(isset($otherServices) && $otherServices->count() > 0): ?>
                                <div class="mt-5 pt-4 border-top">
                                    <h3 class="mb-4" style="font-weight:800; font-size:22px; color:#1a1f36;">Other Available Services</h3>
                                    <div class="row g-3">
                                        <?php $__currentLoopData = $otherServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-6">
                                                <a href="<?php echo e(route('service.detail', $other->slug)); ?>" class="text-decoration-none">
                                                    <div class="p-3 d-flex align-items-center gap-3"
                                                         style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:12px; transition:all 0.2s;"
                                                         onmouseover="this.style.borderColor='#f97316'; this.style.background='#fff7ed';"
                                                         onmouseout="this.style.borderColor='#e2e8f0'; this.style.background='#f8fafc';">
                                                        <img src="<?php echo e($other->image_url); ?>" alt="<?php echo e($other->title); ?>"
                                                             style="width:54px; height:54px; border-radius:10px; object-fit:cover; flex-shrink:0;">
                                                        <div>
                                                            <h5 class="mb-1" style="font-size:15px; font-weight:700; color:#1e293b;"><?php echo e($other->title); ?></h5>
                                                            <span style="font-size:12px; color:#f97316; font-weight:700;">Learn More <i class="bi bi-arrow-right"></i></span>
                                                        </div>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>

                        </div>
                        <!-- Service Entry End -->

                    </div>
                    <!-- Service Single Content End -->
                </div>

                <div class="col-lg-4">
                    <!-- Page Single Sidebar Start -->
                    <?php echo $__env->make('frontend.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Page Single Sidebar End -->
                </div>

            </div>
        </div>
    </div>
    <!-- Page Service Single End -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel\cloudytailz\resources\views/frontend/service-single.blade.php ENDPATH**/ ?>